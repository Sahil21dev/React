export default function App() {
  return (
    <div className="flex h-screen items-center justify-center bg-gradient-to-r from-blue-400 to-purple-500">
      <h1 className="text-4xl font-bold text-white drop-shadow-lg">
        🚀 React + Vite + Tailwind v3 Ready!
      </h1>
    </div>
  )
}
